Author: Vaisnavsing Kautick
Date: October 2020

Description:
This is a short and simple text editor application to write and format text files. The text editor provides basic functionalities to like bold, underline, italics and multi-color texts. The editor is written entirely in python and the GUI was made using the tkinter library.The icon folder stores all the icons used by the program.



Instruction to run program:
	Run the file MyEditor.py to launch the notepad application.
